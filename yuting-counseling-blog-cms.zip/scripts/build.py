#!/usr/bin/env python3
from __future__ import annotations
from datetime import date, datetime
from html import escape
from pathlib import Path
import re, shutil
import markdown, yaml

ROOT = Path(__file__).resolve().parents[1]
DIST = ROOT / "dist"
POSTS_DIR = ROOT / "content" / "posts"
BASE_URL = "https://example.com"


def clean_dist():
    if DIST.exists(): shutil.rmtree(DIST)
    DIST.mkdir()
    for name in ["assets"]:
        src = ROOT / name
        if src.exists(): shutil.copytree(src, DIST / name)


def read_post(path: Path):
    text = path.read_text(encoding="utf-8")
    match = re.match(r"^---\s*\n(.*?)\n---\s*\n(.*)$", text, re.S)
    if not match: raise ValueError(f"Missing YAML frontmatter: {path}")
    meta = yaml.safe_load(match.group(1)) or {}
    body = match.group(2)
    required = ["title", "slug", "date", "category", "excerpt"]
    missing = [x for x in required if not meta.get(x)]
    if missing: raise ValueError(f"Missing {', '.join(missing)}: {path}")
    if not re.fullmatch(r"[a-z0-9-]+", str(meta["slug"])):
        raise ValueError(f"Invalid slug: {path}")
    value = meta["date"]
    if isinstance(value, (date, datetime)): meta["date"] = value.strftime("%Y-%m-%d")
    else: meta["date"] = str(value)
    meta["draft"] = bool(meta.get("draft", True))
    meta["body_html"] = markdown.markdown(body, extensions=["extra", "sane_lists"])
    return meta


def fmt_date(value):
    try: return datetime.strptime(value, "%Y-%m-%d").strftime("%Y.%m.%d")
    except ValueError: return value


def image_html(post, cls=""):
    cover = post.get("cover")
    if not cover: return '<div class="article-cover-placeholder" aria-hidden="true"></div>'
    return f'<img class="{cls}" src="{escape(cover)}" alt="{escape(post.get("cover_alt") or post["title"])}" loading="lazy">'


def card(post, featured=False):
    url = f'articles/{post["slug"]}/'
    if featured:
        return f'''<article class="article-feature">{image_html(post)}<div class="article-content"><span class="tag">{escape(post["category"])}</span><h3><a href="{url}">{escape(post["title"])}</a></h3><p class="muted">{escape(post["excerpt"])}</p><p class="article-meta">{fmt_date(post["date"])}｜{escape(post["category"])}</p></div></article>'''
    return f'''<article><span class="tag">{escape(post["category"])}</span><h3><a href="{url}">{escape(post["title"])}</a></h3><p class="muted">{escape(post["excerpt"])}</p><p class="article-meta">{fmt_date(post["date"])}</p></article>'''


def build_home(posts):
    html = (ROOT / "index.html").read_text(encoding="utf-8")
    cards = card(posts[0], True) + '<div class="article-list">' + ''.join(card(p) for p in posts[1:4]) + '</div>' if posts else '<p class="empty-articles">文章準備中。</p>'
    html, count = re.subn(r'(<div class="article-grid" id="articleGrid">).*?(</div></div></div>\s*</section>)', lambda m: m.group(1)+cards+m.group(2), html, count=1, flags=re.S)
    if count != 1: raise ValueError("Article grid marker not found")
    (DIST / "index.html").write_text(html, encoding="utf-8")


def article_shell(post):
    title = escape(post.get("seo_title") or post["title"])
    description = escape(post.get("seo_description") or post["excerpt"])
    canonical = f'{BASE_URL}/articles/{post["slug"]}/'
    cover = post.get("cover") or "/assets/images/warm-therapy-notebook.webp"
    return f'''<!DOCTYPE html><html lang="zh-Hant-TW"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{title}</title><meta name="description" content="{description}"><link rel="canonical" href="{canonical}"><meta property="og:type" content="article"><meta property="og:title" content="{title}"><meta property="og:description" content="{description}"><meta property="og:image" content="{escape(cover)}"><link rel="stylesheet" href="../../assets/article.css"></head><body><header class="article-header"><a class="article-brand" href="../../"><span aria-hidden="true">≈</span> 徐鈺婷 諮商心理師</a><a href="../">所有文章</a></header><main class="article-main"><article><p class="article-kicker">{escape(post["category"])}</p><h1>{escape(post["title"])}</h1><p class="article-deck">{escape(post["excerpt"])}</p><p class="article-date">{fmt_date(post["date"])}</p>{image_html(post, "article-hero") if post.get("cover") else ""}<div class="article-body">{post["body_html"]}</div></article><nav class="article-return"><a href="../">← 回到文章列表</a><a href="../../#contact">預約諮商</a></nav></main><footer>© 2026 徐鈺婷 諮商心理師</footer></body></html>'''


def build_articles(posts):
    out = DIST / "articles"
    out.mkdir()
    listing = ''.join(f'''<article class="post-card">{image_html(p)}<div><p class="post-meta">{escape(p["category"])} · {fmt_date(p["date"])}</p><h2><a href="{p["slug"]}/">{escape(p["title"])}</a></h2><p>{escape(p["excerpt"])}</p><a class="read-more" href="{p["slug"]}/">閱讀文章 →</a></div></article>''' for p in posts)
    (out / "index.html").write_text(f'''<!DOCTYPE html><html lang="zh-Hant-TW"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>文章分享｜徐鈺婷諮商心理師</title><meta name="description" content="徐鈺婷諮商心理師分享自我探索、原生家庭、依附關係、完美主義、情緒壓力與多元性別相關文章。"><link rel="stylesheet" href="../assets/article.css"></head><body><header class="article-header"><a class="article-brand" href="../"><span aria-hidden="true">≈</span> 徐鈺婷 諮商心理師</a><a href="../#contact">預約諮商</a></header><main class="listing-main"><p class="article-kicker">Articles</p><h1>文章分享</h1><p class="listing-intro">寫一些關於心理、關係與生命經驗的文字。</p><div class="post-list">{listing or '<p>文章準備中。</p>'}</div></main><footer>© 2026 徐鈺婷 諮商心理師</footer></body></html>''', encoding="utf-8")
    for p in posts:
        folder = out / p["slug"]
        folder.mkdir()
        (folder / "index.html").write_text(article_shell(p), encoding="utf-8")


def build_feeds(posts):
    urls = [f"{BASE_URL}/", f"{BASE_URL}/articles/"] + [f'{BASE_URL}/articles/{p["slug"]}/' for p in posts]
    sitemap = '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' + ''.join(f'<url><loc>{u}</loc></url>' for u in urls) + '</urlset>'
    (DIST / "sitemap.xml").write_text(sitemap, encoding="utf-8")
    (DIST / "robots.txt").write_text(f"User-agent: *\nAllow: /\nSitemap: {BASE_URL}/sitemap.xml\n", encoding="utf-8")


def main():
    clean_dist()
    posts = [read_post(p) for p in POSTS_DIR.glob("*.md")]
    posts = sorted((p for p in posts if not p["draft"]), key=lambda p: p["date"], reverse=True)
    build_home(posts); build_articles(posts); build_feeds(posts)
    print(f"Built {len(posts)} published post(s) into {DIST}")

if __name__ == "__main__": main()
