# 徐鈺婷諮商心理師個人網站 Design Spec

## 1. Design Direction
- 方向：米黃色診療室半窗構圖，柔霧光與麂皮牆面
- 核心感受：安靜、可信任、溫暖、讓個案願意停下來
- 首頁 Hero：Winnicott 引言 + 預約諮商按鈕 + 諮商師簡介卡
- 參考架構：個人品牌首頁、關於我、作品/文章、合作/預約入口、聯絡

## 2. Content Architecture
1. Header：Logo/姓名、導覽、主要 CTA
2. Hero：引言、溫柔說明、預約按鈕、簡介卡
3. 關於我：示範學經歷、證照、諮商理念
4. 專長領域：焦慮、憂鬱、關係議題、創傷復原、自我探索、職場壓力
5. 服務項目：個別諮商、伴侶諮商、EAP 諮商、線上諮詢初談
6. 預約諮商：流程 1-2-3、聯絡表單與示範聯絡方式
7. 文章分享：長文區塊，3 篇示範文章
8. 短圖文：短卡片式心理提醒，4 則示範
9. 聯絡我：Email、Line、電話、工作室地址示範

## 3. Visual Tokens
- Background: #F6E8CF, #FFF8EC
- Surface: #FFFCF6, #F2DDC0
- Primary: #8A5F3D
- Primary hover: #6F492C
- Accent sage: #8F9B7B
- Accent terracotta: #C9825A
- Text: #34281F
- Muted: #7C6B5A
- Border: rgba(138, 95, 61, .18)
- Shadow: 0 24px 70px rgba(83, 55, 31, .12)
- Radius: 24px / 32px / 999px

## 4. Typography
- Display: Noto Serif TC / serif fallback
- Body: Noto Sans TC / system sans-serif
- Quote: Cormorant Garamond / Georgia fallback for English quote
- CJK line-height: 1.75–1.9
- CJK letter-spacing: positive .03em–.08em

## 5. Layout
- Max width: 1180px
- Hero desktop: two-column, left quote, right therapist card
- Mobile: single column, CTA first, card below
- Long articles: editorial list/cards
- Short posts: bento grid cards

## 6. Imagery
- Hero visual: quiet counseling studio, beige suede wall, soft morning light, chair, plant, no people, no text
- About/service decorative visual: close-up notebook, warm desk, ceramic cup, soft beige palette, no text
- Generated assets should avoid readable text and avoid replacing the future personal portrait.

## 7. Interaction
- Smooth anchor navigation
- Sticky translucent header
- Buttons: hover lift and pressed feedback
- Appointment form: front-end success message only, non-submitting demo
- Reduced motion supported
- Touch targets >= 44px

## 8. Accessibility
- Semantic landmarks and heading hierarchy
- Visible labels for form fields
- aria-live for form result
- Focus rings retained
- Contrast checked against warm background

## 9. Deliverable
- Static HTML/CSS/JS app
- Public preview URL
- Demo content clearly marked as replaceable
